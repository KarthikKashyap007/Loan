package com.au.api.loan_service.controller;

import com.au.api.loan_service.service.ApplicationConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cache")
public class ApplicationConfigController {

    @Autowired
    private ApplicationConfigService configService;

    @GetMapping("/{key}")
    public String getConfig(@PathVariable String key) {
        return configService.getConfigValue(key);
    }

    @PostMapping("/{key}")
    public void setConfig(@PathVariable String key, @RequestBody String value) {
        configService.setConfigValue(key, value);
    }

    @PutMapping("/{key}")
    public void updateConfig(@PathVariable String key, @RequestBody String value) {
        configService.updateConfigValue(key, value);
    }
}
