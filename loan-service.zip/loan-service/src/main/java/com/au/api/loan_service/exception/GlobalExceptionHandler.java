package com.au.api.loan_service.exception;


import com.au.api.loan_service.Constant.ErrorConstant;
import com.au.api.loan_service.dto.ResponseDto.CommonResponse;
import com.au.api.loan_service.dto.errorDto.ErrorDetails;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.Collections;

@RestControllerAdvice

public class GlobalExceptionHandler {

    @ExceptionHandler(PermissionDeniedException.class)
    public ResponseEntity<CommonResponse<String>> handlePermissionDeniedException(PermissionDeniedException ex) {

        return buildFailureResponse(ErrorConstant.E104, ex.getMessage());

    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<CommonResponse<String>> handleNotFoundException(NotFoundException ex) {

        return buildFailureResponse(ErrorConstant.E103, ex.getMessage());

    }


    @ExceptionHandler(MissingParameterException.class)
    public ResponseEntity<CommonResponse<String>> handleMissingParameterException(MissingParameterException ex) {

        return buildFailureResponse(ErrorConstant.E102, ex.getMessage());

    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<CommonResponse<String>> handleBadRequestException(BadRequestException ex) {

        return buildFailureResponse(ErrorConstant.E101, ex.getMessage());

    }

    @ExceptionHandler(InvalidParameterException.class)
    public ResponseEntity<CommonResponse<String>> handleInvalidParameterException(InvalidParameterException ex) {

        return buildFailureResponse(ErrorConstant.E105, ex.getMessage());

    }

    @ExceptionHandler(InternalServerException.class)
    public ResponseEntity<CommonResponse<String>> handleInternalServerException(InternalServerException ex) {

        return buildFailureResponse(ErrorConstant.E106, ex.getMessage());

    }

    @ExceptionHandler(AuthorisationFailedException.class)
    public ResponseEntity<CommonResponse<String>> handleAuthorisationFailedException(AuthorisationFailedException ex) {

        return buildFailureResponse(ErrorConstant.E107, ex.getMessage());

    }
    private ResponseEntity<CommonResponse<String>> buildFailureResponse(ErrorConstant errorConstant, String errorMessage) {
        CommonResponse<String> response = CommonResponse.Failure(
                errorConstant.getError(),
                errorConstant.getCode(),
                errorMessage + " (" + errorConstant.getErrorMsg() + ")",
                Collections.emptyList(), // Replace with actual errors if available
                "An error occurred while processing your request"// You can provide an errors list if you have it
        );
        return new ResponseEntity<>(response, HttpStatus.valueOf(errorConstant.getCode()));
    }
}
