package com.au.api.loan_service.service;

import com.au.api.loan_service.entity.Customer;
import com.au.api.loan_service.repository.CustomerRepo;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class CustomerService {

    @Autowired
    private CustomerRepo customerRepo;

    public List<Customer> findAll() {

        return customerRepo.findAll();
    }

    public Optional<Customer> findById(Long id) {

        return customerRepo.findById(id);
    }

    @Transactional
    public Customer save(Customer customer) {
        log.info("CustomerService");
        return customerRepo.save(customer);
    }


    @Transactional
    public void deleteById(Long id) {

        customerRepo.deleteById(id);
    }


    public boolean existsById(Long id) {
        return customerRepo.existsById(id);
    }
}

