package com.au.api.loan_service.dto.ResponseDto;

import com.au.api.loan_service.dto.errorDto.ErrorDetails;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommonResponse<T> {

    private T data;
    private String status;
    private int statusCode;
    private List<ErrorDetails> errors;
    private String errorCode;
    private String errorMsg;
    private String msg;

    public static <T> CommonResponse<T> Success(T data, String msg) {
        return CommonResponse.<T>builder()
        .data(data)
        .status("success")
        .statusCode(200)
        .msg(msg)
        .build();
    }

    public static <T> CommonResponse<T> Failure(String errorCode, int code, String errorMsg, List<ErrorDetails> errors,String msg) {
        return CommonResponse.<T>builder()
                .status("fail")
                .statusCode(code)
                .errorCode(errorCode)
                .errorMsg(errorMsg)
                .errors(errors)
                .msg(msg)
                .build();
    }
}
