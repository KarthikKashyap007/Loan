package com.au.api.loan_service.Constant;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum ErrorConstant {

    E104("PERMISSION_DENIED",403,"Permission is Denied"),
    E103("NOT_FOUND",404,"User not Found"),
    E102("MISSING_PARAMETER", 400,"Parameter is Missing"),
    E101("INVALID_PARAMETER", 400,"Invalid or Wrong Parameter"),
    E106("INTERNAL_SERVER_ERROR", 500,"Internal Server Error"),
    E105("BAD_REQUEST", 400,"Bad Request"),
    E107("AUTHORIZATION_FAILED", 401,"Authorizaion Failed");

    private  String error;
    private  int code;
    private String errorMsg;
}
