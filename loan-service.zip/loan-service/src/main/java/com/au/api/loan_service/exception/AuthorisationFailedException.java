package com.au.api.loan_service.exception;

public class AuthorisationFailedException extends RuntimeException {
    public AuthorisationFailedException(String message) {
        super(message);
    }
}
