package com.au.api.loan_service.controller;

import com.au.api.loan_service.dto.ResponseDto.CommonResponse;
import com.au.api.loan_service.entity.Customer;
import com.au.api.loan_service.exception.BadRequestException;
import com.au.api.loan_service.exception.InternalServerException;
import com.au.api.loan_service.exception.NotFoundException;
import com.au.api.loan_service.service.CustomerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/Customer", produces = {MediaType.APPLICATION_JSON_VALUE})
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping(value = "/List")
    public ResponseEntity<CommonResponse<List<Customer>>> getCustomers() {
        log.info("CustomerController::getCustomers()");
        List<Customer> customers = customerService.findAll();
        if (customers.isEmpty()) {
            throw new NotFoundException("No customers found");
        }
        CommonResponse<List<Customer>> response = CommonResponse.Success(customers, "Customers retrieved successfully");
        return ResponseEntity.ok(response);
    }

    @PostMapping(value = "/new")
    public ResponseEntity<CommonResponse<Customer>> addCustomer(@RequestBody Customer customer) {
        log.info("CustomerController::addCustomers()");
        try {
            if (customer == null) {
                throw new BadRequestException("Customer data cannot be null");
            }
            Customer savedCustomer = customerService.save(customer);
            CommonResponse<Customer> response = CommonResponse.Success(savedCustomer, "Customer added successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error adding customer: ", e);
            throw new InternalServerException("An error occurred while adding the customer");
        }
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<CommonResponse<Void>> deleteCustomer(@PathVariable Long id) {
        log.info("CustomerController::deleteCustomer()");
        if (!customerService.existsById(id)) {
            throw new NotFoundException("Customer not found with id " + id);
        }
        customerService.deleteById(id);
        CommonResponse<Void> response = CommonResponse.Success(null, "Customer deleted successfully");
        return ResponseEntity.ok(response);
    }
}
