package com.au.api.loan_service;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Slf4j
@SpringBootApplication
//@EnableTransactionManagement
public class LoanServiceApplication {


//	 static final Logger logger= LoggerFactory.getLogger(LoanServiceApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(LoanServiceApplication.class, args);

		log.info("hi");
		log.error("hi");
		log.trace("hi");
		log.debug("hi");


//		logger.info("hi");

	}

}
