package com.au.api.loan_service.cache;

import com.github.benmanes.caffeine.cache.*;
import jakarta.annotation.Nullable;
import jakarta.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


import java.time.Duration;

@Slf4j
@Component
public class ApplicationConfigCache {

    private LoadingCache<String, String> cache;

    @PostConstruct
    public void initCache() {
        cache = Caffeine.newBuilder()
                .maximumSize(5)
                .refreshAfterWrite(Duration.ofHours(24))
                .removalListener(new RemovalListener<String, String>() {
                    @Override
                    public void onRemoval(@Nullable String key, @Nullable String value, RemovalCause cause) {
                        log.info("Key = " + key + ", value = " + value + " was removed. Reason = " + cause.toString());
                    }
                })
                .build(new CacheLoader<String, String>() {
                    @Override
                    public String load(String key) {
                        log.info("Loading config for key: " + key);
                        return loadConfigFromSource(key);
                    }
                });
    }

    public String getConfig(String key) {
        log.info("Getting config for key: " + key);
        return cache.get(key);
    }

    public void setConfig(String key, String value) {
        log.info("Setting config for key: " + key + " with value: " + value);
        cache.put(key, value);
    }

    public void updateConfig(String key, String value) {
        cache.put(key, value);
    }

    private String loadConfigFromSource(String key) {
        // Implement the logic to load the config value from the source (e.g., database, external service)
        String defaultValue = "default_config_value";
        log.info("Loaded default config value for key: " + key + " -> " + defaultValue);
        return defaultValue;
    }
}
