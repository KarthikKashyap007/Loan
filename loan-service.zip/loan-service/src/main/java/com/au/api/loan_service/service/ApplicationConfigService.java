package com.au.api.loan_service.service;

import com.au.api.loan_service.cache.ApplicationConfigCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplicationConfigService {

    @Autowired
    private ApplicationConfigCache cacheManager;

    public String getConfigValue(String key) {
        return cacheManager.getConfig(key);
    }

    public void setConfigValue(String key, String value) {
        cacheManager.setConfig(key, value);
    }

    public void updateConfigValue(String key, String value) {
        cacheManager.updateConfig(key, value);
    }
}
