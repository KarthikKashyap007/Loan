package com.au.api.loan_service.config.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;


@Slf4j
public class BasicAuthHandlerInterceptor implements HandlerInterceptor {

    private String generate32DigitId(){
        return UUID.randomUUID().toString().replace("-","");
    }


    private static final String username="admin";
    private static final String password="admin";

    //Authorization: Basic YWRtaW46YWRtaW4=
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        log.info("BasicAuthHandlerInterceptor::preHandle = ",request.getRequestURI());

        String authId = request.getHeader("x-req-Id");
        if (authId == null || authId.isEmpty()){
            authId = generate32DigitId();
            request.setAttribute("x-req-id",authId);
            log.info("AuthId Set = "+authId);
        }
        response.setHeader("x-req-id",authId);



            String authHeader= request.getHeader("Authorization");
        if(StringUtils.hasText(authHeader) && authHeader.startsWith("Basic ")){
            String base64Creds= authHeader.substring("Basic ".length());
            byte[] decodeCreds= Base64.getDecoder().decode(base64Creds);
            String creds= new String(decodeCreds, StandardCharsets.UTF_8);

            String[] parts=creds.split(":");
            if(username.equals(parts[0]) && password.equals(parts[1])){
                log.info("Authorized");
                return true;
            }
        }
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED,"Unauthorized");
        return false;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        log.info("BasicAuthHandlerInterceptor::postHandle");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        log.info("BasicAuthHandlerInterceptor::afterCompletion ");
    }
}


