package com.au.api.loan_service.mapper;

import com.au.api.loan_service.dto.CustomerDTO;
import com.au.api.loan_service.entity.Customer;

public class CustomerMapper {

    public static CustomerDTO toDTO(Customer customer){
        return new CustomerDTO(
                customer.getId(),
                customer.getName(),
                customer.getAccountNo()
        );
    }
    public static Customer toEntity(CustomerDTO dto){
        return new Customer(
                dto.getId(),
                dto.getName(),
                dto.getAccountNo(),
                0
        );
    }
}
